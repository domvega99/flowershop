export class CreateEmployeeDto {}
